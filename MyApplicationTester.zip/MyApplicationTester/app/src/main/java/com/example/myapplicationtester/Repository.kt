package com.example.myapplicationtester

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Repository {
    private val _data: MutableLiveData<JsonObject?> = MutableLiveData(null)
    val data: LiveData<JsonObject?> get() = _data

    fun fetch() {

        val rateApi = RetrofitHelper.getInstance().create(ApiInterface::class.java)

        rateApi.getRates().enqueue(object : Callback<JsonObject> {

            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {

                val res = response.body()
                _data.value=res
                Log.d("ayush: ", res.toString())

            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {

            }
        })
    }

}