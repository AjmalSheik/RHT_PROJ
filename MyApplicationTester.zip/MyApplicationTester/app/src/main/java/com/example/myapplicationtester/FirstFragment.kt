package com.example.myapplicationtester

import android.R
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.example.myapplicationtester.databinding.FragmentFirstBinding
import com.google.gson.JsonObject
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null


    private val binding get() = _binding!!
    private val viewModel by viewModels<MainViewModel>()
    var curr = arrayOf("USD")
    var curr2 = arrayOf("AED","ARS","AUD","CAD","CHF")
    val NEW_SPINNER_ID = 1
    var editText:EditText?=null
    var editText2:EditText?=null
    var usdVal:Double=0.00
    var aedVal:Double=0.00
    var spinner:Spinner?=null
    var spinner2:Spinner?=null

    var selected="AED"
    var jsonObject1:JsonObject?=null


    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)



         spinner = binding.spinner1
         spinner2 = binding.spinner2
         editText = binding.ed1
         editText2 = binding.ed2

        editText?.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {
                //editText2?.setText((usdVal*aedVal).toString())

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
               // editText2?.setText((usdVal*aedVal).toString())
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                if(s.isNotEmpty()) {
                    usdVal = editText?.text.toString().toDouble()
                    editText2?.setText((usdVal * aedVal).toString())
                }
            }
        })
        editText2?.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {
                //editText2?.setText((usdVal*aedVal).toString())

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
                // editText2?.setText((usdVal*aedVal).toString())
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
//                aedVal=editText2?.text.toString().toDouble()
//                editText?.setText((usdVal*aedVal).toString())
            }
        })

        if (spinner != null) {
            val adapter = ArrayAdapter(
                activity!!,
                R.layout.simple_spinner_item, curr
            )
            spinner?.adapter = adapter
        }

        if (spinner2 != null) {
            val adapter2 = ArrayAdapter(
                activity!!,
                R.layout.simple_spinner_item, curr2
            )
            spinner2?.adapter = adapter2
            spinner2?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selected=curr2.get(position)

                    if(jsonObject1!=null){
                        if(selected=="AED"){
                            aedVal=   jsonObject1?.get("AED")?.toString()!!.toDouble()
                            editText2?.setText(aedVal.toString())
                        }

                        if(selected=="ARS"){
                            aedVal=   jsonObject1?.get("ARS")?.toString()!!.toDouble()
                            editText2?.setText(aedVal.toString())
                        }
                        if(selected=="AUD"){
                            aedVal=   jsonObject1?.get("AUD")?.toString()!!.toDouble()
                            editText2?.setText(aedVal.toString())
                        }
                        if(selected=="CAD"){
                            aedVal=   jsonObject1?.get("CAD")?.toString()!!.toDouble()
                            editText2?.setText(aedVal.toString())
                        }
                        if(selected=="CHF"){
                            aedVal=   jsonObject1?.get("CHF")?.toString()!!.toDouble()
                            editText2?.setText(aedVal.toString())
                        }

                        editText2?.setText((usdVal*aedVal).toString())
                    }


                }

            }        }

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getData().observe(this, Observer {

            it?.let { res ->

                 jsonObject1= res.get("rates") as JsonObject
                Log.d("name ",res.get("rates").toString())
                usdVal=     jsonObject1?.get("USD")?.toString()!!.toDouble()
                aedVal=   jsonObject1?.get("AED")?.toString()!!.toDouble()
                editText?.setText(usdVal.toString())
                editText2?.setText(aedVal.toString())


            }
        })




    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}