package com.example.myapplicationtester

data class RateModel(
    var base_code: String,
    var documentation: String,
    var provider: String,
    var rates: Rates,
    var result: String,
    var terms_of_use: String,
    var time_eol_unix: Int,
    var time_last_update_unix: Int,
    var time_last_update_utc: String,
    var time_next_update_unix: Int,
    var time_next_update_utc: String
)