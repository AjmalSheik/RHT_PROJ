package com.example.myapplicationtester

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.google.gson.JsonObject

class MainViewModel:ViewModel() {

    private val repository = Repository()

    fun getData(): LiveData<JsonObject?> {

        repository.fetch()
        return repository.data
    }

}