package com.example.myapplicationtester

import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET


interface ApiInterface {
    @GET("v6/latest/USD")
     fun getRates() : Call<JsonObject>
}